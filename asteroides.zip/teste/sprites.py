import pygame as pg
from PIL import Image
from utils import Vec

def load_gif(path, scale=1):
    gif = Image.open(path)
    frames = []

    for frame in range(gif.n_frames):
        gif.seek(frame)
        frame_img = gif.convert("RGBA")
        frame_pg = pg.image.fromstring(frame_img.tobytes(), frame_img.size, "RGBA")

        if scale != 1:
            w = int(frame_pg.get_width() * scale)
            h = int(frame_pg.get_height() * scale)
            frame_pg = pg.transform.scale(frame_pg, (w, h))

        frames.append(frame_pg)

    return frames


class AnimatedSprite(pg.sprite.Sprite):
    def __init__(self, pos, gif_path, scale=1, fps=12):
        super().__init__()
        self.frames = load_gif(gif_path, scale)
        self.frame_index = 0
        self.fps = fps
        self.timer = 0
        self.pos = Vec(pos)
        self.image = self.frames[0]
        self.rect = self.image.get_rect(center=self.pos)

    def update(self, dt):
        self.timer += dt
        if self.timer >= (1 / self.fps):
            self.timer = 0
            self.frame_index = (self.frame_index + 1) % len(self.frames)
            self.image = self.frames[self.frame_index]
            self.rect = self.image.get_rect(center=self.pos)

    def draw(self, surf):
        surf.blit(self.image, self.rect.topleft)


# 🔥 Nave com animação
class Ship(AnimatedSprite):
    def __init__(self, pos):
        super().__init__(pos, "assets/ship.gif", scale=1.2)
        self.vel = Vec(0, 0)
        self.angle = 0

    def rotate(self, angle):
        self.angle += angle
        self.image = pg.transform.rotate(self.frames[self.frame_index], -self.angle)
        self.rect = self.image.get_rect(center=self.pos)


# 👾 UFO animado
class UFO(AnimatedSprite):
    def __init__(self, pos, speed):
        super().__init__(pos, "assets/ufo.gif", scale=1.2)
        self.speed = speed

    def update(self, dt):
        super().update(dt)
        self.pos.x += self.speed * dt
        self.rect.center = self.pos.xy
